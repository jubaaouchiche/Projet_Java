public interface Technique{ //Interface permettant à seulement certains Fighter de posséder une Technique

	public void technique();

} 
