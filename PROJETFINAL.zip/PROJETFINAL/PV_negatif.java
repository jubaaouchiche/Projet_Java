public class PV_negatif extends Exception{ // déclenche une exception sur les pv négatifs

    public PV_negatif(String message){
    	super(message);
    }
    		
}   		
    		
    		
    

